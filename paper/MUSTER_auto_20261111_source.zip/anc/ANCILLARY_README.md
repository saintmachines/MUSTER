# SDK MemoryAgentBench results

The original implementation is the comparison baseline. `native_mab_cells.csv` contains 42 cells for three readers with the paper configuration held fixed. `auto4omini_mab_cells.csv` contains 14 cells with per-store automatic derivation and LongMemEval's rounds adapter. Both retain the original benchmark metrics, question denominators and reference answers. The old and new columns preserve the source scores at full precision. Table 1 displays one decimal and the complete-cell tables display two.

Changed complete reader inputs are read anew. Archived answers are reused after matching the full messages and request settings. Judgments are reused after matching the full judge payload. DetectiveQA retains three reads per question. Overall is the mean of AR, TTL, LRU and SF within MemoryAgentBench. MCC is the mean of its five cells, and TTL is the mean of MCC and Recsys. Infini-style columns retain the original implementation's values. SDK (paper settings) and Auto have no new Infini-style evaluation.

The native rules were developed using the 600 FactConsolidation questions at the smaller scales and the reported 262K stores.

Primary metric receipt SHA256: `b59a231b51a115449da1cbc6c144ffdffa5b07be023bc3266d41f6183395f204`.

Automatic-configuration metric receipt SHA256: `77b3d497e8d2dd61842bcf159e9c81ab1722d141df8ddffd9ac94f9612e144f6`.

`frontier_native_mab_cells.csv` adds 28 cells for GLM-5.3-Flash and GPT-6 Luna with the paper settings. Each reader contributes 1,671 questions and 1,813 response slots including DetectiveQA's three reads: 224 changed-input slots are read anew and 1,589 reuse archived answers. The original high-effort request, provider, scoring and empty-answer fallback contracts are retained. These rows concern MemoryAgentBench; the existing six-setting mean is preserved.

`representative_sdk_mab_rows.csv` gives the current SDK's paper-settings rows for five readers and its separate automatic 4o-mini row. `sdk_policy_comparison_cells.csv` gives the 14-cell SDK parent-priority and structure-matched policy results. The earlier no-detection and balanced controls retain their original implementation conditions. Other benchmarks, Infini-style judgments, the six-setting mean and build measurements retain their original implementation values.

The policy table displays one decimal place, rounded half up. Numeric CSVs retain their original full precision.

`auto_additional_mab_cells.csv` adds the completed GPT-4.1-mini and GPT-5-mini per-store Auto runs. The protocol chunk size and LongMemEval rounds adapter are retained. Overall is the mean of the four competencies. The two FactConsolidation cells reuse identical full requests from the SDK paper-settings runs. Each additional reader has 1,671 evaluated positions and 1,813 response slots including DetectiveQA repeats.
