
SDK 0.1.3 final refresh: the current table cells are in collection_auto_mab_cells.csv. API_INPUT_REPLAY.json records 1,450 matching and 21 changed complete non-FC inputs. LME_REFRESH.json binds all 300 judgments for each of five readers to the input inventory and raw-record hashes. The other CSVs retain their historical versions and scopes.
